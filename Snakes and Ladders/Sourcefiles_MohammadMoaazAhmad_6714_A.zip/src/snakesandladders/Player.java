package snakesandladders;

/**
 * Created by MMA on 4/5/2016.
 */
public class Player {

    int playerNumber;
    int score;
    boolean status;

    Player(){
        playerNumber = -1;
        score = 0;
        status = true;
    }
}
